#pragma once

#include <stdint.h>

void ParallelSort(uint32_t *data, uint32_t n, int p);